#include "IG2App.h"

using namespace Ogre;
using namespace std;

bool IG2App::keyPressed(const OgreBites::KeyboardEvent& evt){
        
    // ESC key finished the rendering...
    if (evt.keysym.sym == SDLK_ESCAPE){
        getRoot()->queueEndRendering();
    }

    if (evt.keysym.sym == SDLK_s) {
        _gameScene->setVisible(true);
        _introScene->setVisible(false);
    }

    if (_gameScene->getVisible())
        _gameScene->keyPressed(evt);

	return true;
}

void IG2App::shutdown(){
    
  mShaderGenerator->removeSceneManager(mSM);
  mSM->removeRenderQueueListener(mOverlaySystem);  
					
  mRoot->destroySceneManager(mSM);  

  delete mTrayMgr;  mTrayMgr = nullptr;
  delete mCamMgr; mCamMgr = nullptr;
  
  // do not forget to call the base 
  //IG2ApplicationContext::shutdown();
    OgreBites::ApplicationContext::shutdown();
}

void IG2App::setup(void){
    
    // do not forget to call the base first
    //IG2ApplicationContext::setup();
    OgreBites::ApplicationContext::setup();

    // Create the scene manager
    mSM = mRoot->createSceneManager();

    // Register our scene with the RTSS
    mShaderGenerator->addSceneManager(mSM);

    mSM->addRenderQueueListener(mOverlaySystem);
    mTrayMgr = new OgreBites::TrayManager("TrayGUISystem", getRenderWindow());
    mTrayMgr->showFrameStats(OgreBites::TL_BOTTOMLEFT);

    addInputListener(mTrayMgr);
    
    // Adds the listener for this object
    addInputListener(this);
    setupScene();
}

void IG2App::createCamera(){
    Camera* cam = mSM->createCamera("Cam");
    cam->setNearClipDistance(1);
    cam->setFarClipDistance(10000);
    cam->setAutoAspectRatio(true);
    //cam->setPolygonMode(Ogre::PM_WIREFRAME);

    mCamNode = mSM->getRootSceneNode()->createChildSceneNode("nCam");
    mCamNode->attachObject(cam);

    // and tell it to render into the main window
    Viewport* vp = getRenderWindow()->addViewport(cam);

    mCamMgr = new OgreBites::CameraMan(mCamNode);
    addInputListener(mCamMgr);
    mCamMgr->setStyle(OgreBites::CS_ORBIT);
}

void IG2App::setupScene(void){
    createCamera();
    _introScene = new IntroScene(mSM, mTrayMgr, light, mLightParent, mLightNode, mCamNode, mCamMgr);
    _introScene->setVisible(true);
    _gameScene = new GameScene(mSM, mTrayMgr, light, mLightParent, mLightNode, mCamNode, mCamMgr);
    _gameScene->setVisible(false);
}

void IG2App::frameRendered(const Ogre::FrameEvent& evt)
{
    if (_introScene->getVisible()) _introScene->update(evt);
    else if (_gameScene->getVisible())
    {
        _gameScene->update(evt);
        if (_gameScene->getEndGame())
            getRoot()->queueEndRendering();
    }
}



